#!/bin/sh

rm -rf project
mkdir project
cp ../../common/synthesis/de10_lite/*.q[ps]f project
