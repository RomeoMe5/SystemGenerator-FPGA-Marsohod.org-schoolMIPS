#!/bin/sh

rm -rf project
mkdir project
cp ../../common/synthesis/de0_cv/*.q[ps]f project
