#!/bin/sh
# clean.sh

. ./setup.sh

rm -rf $SIM_DIR $SYN_DIR
